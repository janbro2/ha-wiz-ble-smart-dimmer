# Publishing checklist (repository owner)

The public repository has been created at **https://github.com/janbro2/ha-wiz-ble-smart-dimmer**. The project files have not yet been uploaded. This checklist tracks publication tasks.

1. [x] Create the **public GitHub repository** `janbro2/ha-wiz-ble-smart-dimmer`. Do not publish local Home Assistant configuration, private addresses or diagnostics.
2. [ ] Upload the **project contents** to the repository root, not a surrounding nested directory.
3. [x] Prepare repository-specific `documentation`, `issue_tracker` and `codeowners` metadata to `manifest.json`.
4. [x] Include `hacs.json` in the repository root. The project is laid out as a custom integration in `custom_components/wiz_ble_dimmer`.
5. Run `python -m unittest discover -s tests -v`; review GitHub Actions results. Test installation on a clean Home Assistant instance before promoting it widely.
6. Optionally create a tagged release, e.g. `v0.2.0`, and submit the repository to Home Assistant's Marketplace/community catalog when it meets the current publishing requirements. **Listing acceptance is not guaranteed.**
7. For users who want easy automation installation, share the URL to the raw `blueprints/automation/wiz_ble_dimmer/remote_8_buttons.yaml` GitHub file.

### Privacy review

- No real WiZ remote MAC address is embedded in the source.
- The setup form asks each installer to enter their own MAC.
- Example address `AA:BB:CC:DD:EE:FF` is fictional.
- Example automation uses no personal HA device names or user names.
- Do not upload diagnostic dumps or exported `.storage` files unless fully sanitized.

### Scope and disclosure

Label this project **experimental**, and keep the `2026.11.2` known-working version visible in the README. No official WiZ/Philips/Signify endorsement or protocol documentation was used. The Bluetooth format was obtained from one owner's observed advertisement packets.
